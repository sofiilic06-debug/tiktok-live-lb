exports.handler = async (event, context) => {
  try {
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body);
      console.log("📩 Primljen TikTok event:", body);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "TikTok webhook received successfully!" }),
      };
    }

    return {
      statusCode: 200,
      body: "TikTok webhook is active.",
    };
  } catch (error) {
    console.error("❌ Webhook error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server error" }),
    };
  }
};